import torch
import os, csv, re
import pandas as pd
from tqdm import tqdm
import soundfile as sf
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import evaluate

cer_metric = evaluate.load("cer")

def normalize_text(s):
    s = s.lower()
    s = re.sub(r"[^\w\s]", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def collect_test_samples(segments_dir, gt_dir):
    entries = []
    for speaker_folder in sorted(os.listdir(segments_dir)):
        speaker_path = os.path.join(segments_dir, speaker_folder)
        gt_csv = os.path.join(gt_dir, f"{speaker_folder}.csv")
        if not os.path.isdir(speaker_path) or not os.path.exists(gt_csv):
            continue
        with open(gt_csv, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                fname = row["filename"]
                trans = row["transcription"]
                wav_path = os.path.join(speaker_path, fname)
                if os.path.exists(wav_path):
                    entries.append({
                        "path": wav_path,
                        "filename": fname,
                        "transcription": trans
                    })
    return entries

def evaluate_testset_streaming(model_dir, segments_dir, gt_dir, tag, output_dir):
    # 加载模型
    model = WhisperForConditionalGeneration.from_pretrained(model_dir).to("cuda")
    processor = WhisperProcessor.from_pretrained(model_dir)
    model.eval()
    metric = evaluate.load("wer")

    # 准备数据
    entries = collect_test_samples(segments_dir, gt_dir)
    print(f"🔍 Found {len(entries)} test samples.\n")

    output_csv = os.path.join(output_dir, f"predictions_{tag}.csv")

    # 初始化CSV文件写入
    with open(output_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "filename", "speaker", "reference_norm", "prediction_norm",
            "WER_sentence", "CER_sentence"
        ])
        writer.writeheader()

        preds_norm, refs_norm = [], []

        for entry in tqdm(entries, desc="Transcribing", ncols=100):
            audio_array, sample_rate = sf.read(entry["path"])
            inputs = processor(audio_array, sampling_rate=sample_rate, return_tensors="pt").input_features.to("cuda")

            with torch.no_grad():
                forced_decoder_ids = processor.get_decoder_prompt_ids(language="dutch", task="transcribe")
                pred_ids = model.generate(inputs, max_length=225, forced_decoder_ids=forced_decoder_ids)
            prediction = processor.batch_decode(pred_ids, skip_special_tokens=True)[0]
            reference = entry["transcription"]
            speaker = entry["filename"].split("_")[0]

            wer_sentence = metric.compute(predictions=[normalize_text(prediction)], references=[normalize_text(reference)])
            cer_sentence = cer_metric.compute(predictions=[normalize_text(prediction)], references=[normalize_text(reference)])

            row = {
                "filename": entry["filename"],
                "speaker": speaker,
                "reference_norm": normalize_text(reference),
                "prediction_norm": normalize_text(prediction),
                "WER_sentence": round(wer_sentence * 100, 2),
                "CER_sentence": round(cer_sentence * 100, 2)
            }

            writer.writerow(row)

            preds_norm.append(row["prediction_norm"])
            refs_norm.append(row["reference_norm"])

    # 计算normalized WER
    wer_norm = metric.compute(predictions=preds_norm, references=refs_norm)
    cer_norm = cer_metric.compute(predictions=preds_norm, references=refs_norm)

    print(f"\nWER (normalized): {wer_norm * 100:.2f}%")
    print(f"CER (normalized): {cer_norm * 100:.2f}%")
    print(f"Results saved to: {output_csv}")

    df = pd.read_csv(output_csv)
    speakers = df["speaker"].unique()
    summary = []

    for spk in sorted(speakers):
        spk_df = df[df["speaker"] == spk]
        wer = metric.compute(predictions=spk_df["prediction_norm"].tolist(), references=spk_df["reference_norm"].tolist())
        cer = cer_metric.compute(predictions=spk_df["prediction_norm"].tolist(), references=spk_df["reference_norm"].tolist())
        summary.append({
            "speaker": spk,
            "WER_normalized": round(wer * 100, 2),
            "CER_normalized": round(cer * 100, 2)
        })

    summary.append({
        "speaker": "OVERALL",
        "WER_normalized": round(wer_norm * 100, 2),
        "CER_normalized": round(cer_norm * 100, 2)
    })
    output_summary_path = os.path.join(output_dir, f"summary_wer_{tag}.csv")
    pd.DataFrame(summary).to_csv(output_summary_path, index=False, columns=["speaker", "WER_normalized", "CER_normalized"])
    print(f"Speaker-level normalized WER saved to {output_summary_path}")

    return wer_norm

evaluate_testset_streaming(
    model_dir="/scratch/s5910587/whisper_ft/td_only/eval_model",
    segments_dir="/scratch/s5910587/data_asd/segs_test",
    gt_dir="/scratch/s5910587/data_asd/GT_test",
    tag="td_only",
    output_dir="/scratch/s5910587/whisper_eval_sentence/td_only"
)
